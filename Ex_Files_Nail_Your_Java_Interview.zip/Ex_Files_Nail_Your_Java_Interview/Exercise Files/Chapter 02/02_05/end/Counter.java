public class Counter {

    int count = 0;
    
    amount

    public void incrementCount(int amount) {
        this.count += amount;
    }
    
    amount


}