public class Counter {

    int count = 0;

    public void incrementCount(int amount) {
        this.count += amount;
    }


}