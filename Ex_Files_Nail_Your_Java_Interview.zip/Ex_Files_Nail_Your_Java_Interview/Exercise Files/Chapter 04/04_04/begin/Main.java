import java.util.Stack;

public class Main {

    public static void main(String[] args) {
        Stack<String> deckOfCards = new Stack();
        String card1 = "Jack : Diamonds";
        String card2 = "8 : Hearts";
        String card3 = "3 : Clubs";
    }
}
