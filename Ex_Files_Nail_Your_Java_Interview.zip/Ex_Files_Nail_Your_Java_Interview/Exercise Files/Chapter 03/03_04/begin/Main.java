public class Main {

    public static void main(String[] args) {

        String a = "Apples";
        String b = "Bananas";
        String o = "Oranges";
        String bp = "Banana Peels";
        String p = "Pears";
        String[] fruits = {a, b, o, bp, p};





        // Getting a character at a specific index
        // Print a string if it contains a substring
        // Grab a substring using two indexes
        // Print a reverse String
    }
}
