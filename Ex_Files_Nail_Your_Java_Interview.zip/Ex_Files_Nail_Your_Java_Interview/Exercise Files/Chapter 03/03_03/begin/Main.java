public class Main {

    public static void main(String[] args) {
        String p = "   Panda";
        String f = " Fish ";
        String h = "Horse     ";
        String c = " Cat";
        String nothing = " ";
        String[] strings = {p, f, c, h, nothing};
    }
}
