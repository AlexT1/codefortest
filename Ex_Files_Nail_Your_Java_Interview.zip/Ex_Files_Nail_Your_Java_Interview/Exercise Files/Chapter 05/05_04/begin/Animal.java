public class Animal {

    public String sound() {
        return "An animal is making a sound";
    }
}