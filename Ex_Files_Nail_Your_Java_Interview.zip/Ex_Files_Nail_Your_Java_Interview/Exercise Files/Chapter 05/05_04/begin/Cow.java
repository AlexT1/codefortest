public class Cow  {

}