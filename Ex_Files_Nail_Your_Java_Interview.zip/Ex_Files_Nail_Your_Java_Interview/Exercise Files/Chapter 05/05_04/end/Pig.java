public class Pig extends Animal {

    @Override
    public String sound() {
        return "Oink!";
    }

}