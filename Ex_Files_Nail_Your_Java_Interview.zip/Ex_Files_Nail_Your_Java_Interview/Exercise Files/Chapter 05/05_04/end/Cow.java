public class Cow extends Animal {

    @Override
    public String sound() {
        return "Moo!";
    }
}