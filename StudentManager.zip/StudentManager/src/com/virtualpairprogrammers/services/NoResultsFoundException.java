package com.virtualpairprogrammers.services;

public class NoResultsFoundException extends Exception {

}
