package com.frankmoley.lil.designpatternsapp.prototype;

public class ProtoTrue {
}
