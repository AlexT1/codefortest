package com.frankmoley.lil.designpatternsapp.prototype;

public class ProtoFalse {
}
