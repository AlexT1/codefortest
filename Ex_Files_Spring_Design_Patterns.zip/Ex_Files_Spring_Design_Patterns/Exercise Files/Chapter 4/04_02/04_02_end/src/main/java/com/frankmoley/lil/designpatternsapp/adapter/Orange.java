package com.frankmoley.lil.designpatternsapp.adapter;

public interface Orange {
    String getVariety();
    void eat();
    void peel();
    void juice();
}
