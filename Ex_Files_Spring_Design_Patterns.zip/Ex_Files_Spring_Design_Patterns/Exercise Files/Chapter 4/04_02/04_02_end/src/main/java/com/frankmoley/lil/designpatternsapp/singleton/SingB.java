package com.frankmoley.lil.designpatternsapp.singleton;

import org.springframework.stereotype.Component;

@Component
public class SingB {
}
