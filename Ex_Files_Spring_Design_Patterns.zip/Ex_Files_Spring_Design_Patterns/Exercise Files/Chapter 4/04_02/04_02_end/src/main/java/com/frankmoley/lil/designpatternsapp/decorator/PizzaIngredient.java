package com.frankmoley.lil.designpatternsapp.decorator;

public abstract class PizzaIngredient extends Pizza {
    public abstract String getDescription();
}
