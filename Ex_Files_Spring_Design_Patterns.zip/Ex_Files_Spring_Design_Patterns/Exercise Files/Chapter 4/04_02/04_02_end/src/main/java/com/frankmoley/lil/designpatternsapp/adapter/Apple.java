package com.frankmoley.lil.designpatternsapp.adapter;

public interface Apple {
    String getVariety();
    void eat();
}
